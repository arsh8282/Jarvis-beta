# JARVIS Chat (core v0.1)

Kivy app for chatting with Gemini. Stdlib-only HTTP client, so no extra Python dependencies.

Included: API key validation, live model discovery (filtered to generateContent), model selection,
multi-turn chat with JARVIS system instruction, long-press menu (Copy, Select Text), local config storage.

Not yet included: voice input, text-to-speech, speech toggle, persistent chat history, settings panel,
unit tests, Colab notebook.

Security: an API key stored on a phone can be extracted. Keys are redacted from error messages and never logged.

Build: `buildozer -v android debug` on Linux or in Colab.
