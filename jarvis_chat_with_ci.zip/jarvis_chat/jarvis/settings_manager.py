DEFAULT_INSTRUCTION = (
    "You are JARVIS, a friendly and professional AI assistant. "
    "Always address the user as Sir. Understand Hindi, English and Hinglish; "
    "reply in simple Hinglish for technical explanations. Keep answers readable."
)


class SettingsManager:
    def __init__(self, storage):
        self.storage = storage
        self.data = storage.load()

    @property
    def api_key(self):
        return self.data.get("api_key", "")

    @property
    def model(self):
        return self.data.get("model", "")

    @property
    def instruction(self):
        return self.data.get("instruction", DEFAULT_INSTRUCTION)

    def update(self, **kwargs):
        self.data.update(kwargs)
        self.storage.save(self.data)
