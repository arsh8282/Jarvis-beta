"""Minimal Gemini REST client using only the standard library (Android-safe)."""
import json
import urllib.error
import urllib.request

API_BASE = "https://generativelanguage.googleapis.com/v1beta"


class GeminiError(Exception):
    pass


def _request(method, path, api_key, body=None):
    data = json.dumps(body).encode("utf-8") if body is not None else None
    req = urllib.request.Request(
        API_BASE + path,
        data=data,
        method=method,
        headers={"Content-Type": "application/json", "x-goog-api-key": api_key},
    )
    try:
        with urllib.request.urlopen(req, timeout=40) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code in (400, 403):
            raise GeminiError("Invalid API key or request was refused. Check the key.")
        if e.code == 429:
            raise GeminiError("Rate limit or quota reached. Wait a moment and retry.")
        raise GeminiError(f"Server error (HTTP {e.code}). Please retry.")
    except (urllib.error.URLError, TimeoutError, OSError):
        raise GeminiError("Network error or timeout. Check connection and retry.")


def list_generation_models(api_key):
    """Return [(model_id, display_name)] for models supporting generateContent."""
    models, token = [], None
    while True:
        path = "/models?pageSize=100" + (f"&pageToken={token}" if token else "")
        data = _request("GET", path, api_key)
        for m in data.get("models", []):
            if "generateContent" in m.get("supportedGenerationMethods", []):
                mid = m.get("name", "").replace("models/", "")
                models.append((mid, m.get("displayName", mid)))
        token = data.get("nextPageToken")
        if not token:
            break
    if not models:
        raise GeminiError("No text-generation models available for this key.")
    return sorted(models)


def generate_reply(api_key, model, history, system_instruction):
    """history: list of {'role': 'user'|'model', 'text': str}. Returns reply text."""
    body = {
        "system_instruction": {"parts": [{"text": system_instruction}]},
        "contents": [
            {"role": h["role"], "parts": [{"text": h["text"]}]} for h in history
        ],
    }
    data = _request("POST", f"/models/{model}:generateContent", api_key, body)
    feedback = data.get("promptFeedback", {})
    if feedback.get("blockReason"):
        raise GeminiError(f"Blocked by safety filter: {feedback['blockReason']}")
    candidates = data.get("candidates") or []
    if not candidates:
        raise GeminiError("Empty response from Gemini. Please retry.")
    parts = candidates[0].get("content", {}).get("parts", [])
    text = "".join(p.get("text", "") for p in parts).strip()
    if not text:
        raise GeminiError("Empty response from Gemini. Please retry.")
    return text


def redact(text, api_key):
    """Remove the API key from any string before it is shown or logged."""
    return text.replace(api_key, "[REDACTED]") if api_key else text
