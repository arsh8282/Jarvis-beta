import threading

from kivy.app import App
from kivy.clock import Clock
from kivy.core.clipboard import Clipboard
from kivy.metrics import dp
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.popup import Popup
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.scrollview import ScrollView
from kivy.uix.spinner import Spinner
from kivy.uix.textinput import TextInput

from jarvis.gemini_client import (GeminiError, list_generation_models,
                                  generate_reply, redact)
from jarvis.settings_manager import SettingsManager
from jarvis.storage import Storage

CYAN = (0.0, 0.85, 1.0, 1)
BG = (0.02, 0.03, 0.06, 1)
TEXT = (0.9, 0.95, 1, 1)


class Bubble(Label):
    """AI/user message. Long-press opens Copy / Select Text menu (AI only)."""
    def __init__(self, text, is_ai, on_long_press=None, **kw):
        super().__init__(text=text, size_hint_y=None, color=TEXT, markup=False,
                         halign="left", valign="top", padding=(dp(12), dp(10)), **kw)
        self.is_ai = is_ai
        self.full_text = text
        self.on_long_press = on_long_press
        self._timer = None
        self._start = None
        self.bind(width=lambda *_: setattr(self, "text_size", (self.width - dp(24), None)),
                  texture_size=lambda *_: setattr(self, "height", self.texture_size[1] + dp(20)))
        self.canvas.before.clear()

    def on_touch_down(self, touch):
        if self.collide_point(*touch.pos) and self.is_ai and self.on_long_press:
            self._start = touch.pos
            self._timer = Clock.schedule_once(lambda dt: self.on_long_press(self), 0.6)
        return super().on_touch_down(touch)

    def on_touch_move(self, touch):
        if self._timer and self._start:
            dx = abs(touch.pos[0] - self._start[0])
            dy = abs(touch.pos[1] - self._start[1])
            if dx > dp(10) or dy > dp(10):   # moved = scrolling, cancel long-press
                self._cancel()
        return super().on_touch_move(touch)

    def on_touch_up(self, touch):
        self._cancel()
        return super().on_touch_up(touch)

    def _cancel(self):
        if self._timer:
            self._timer.cancel()
            self._timer = None


class SetupScreen(Screen):
    def __init__(self, app, **kw):
        super().__init__(name="setup", **kw)
        self.app = app
        root = BoxLayout(orientation="vertical", padding=dp(20), spacing=dp(12))
        root.add_widget(Label(text="JARVIS SETUP", color=CYAN, font_size=dp(26), size_hint_y=None, height=dp(50)))
        self.key_input = TextInput(hint_text="Gemini API key", password=True, multiline=False,
                                   size_hint_y=None, height=dp(48))
        root.add_widget(self.key_input)
        show = Button(text="Show / hide key", size_hint_y=None, height=dp(40))
        show.bind(on_release=lambda *_: setattr(self.key_input, "password", not self.key_input.password))
        root.add_widget(show)
        self.status = Label(text="Get a key at aistudio.google.com/apikey", color=TEXT,
                            size_hint_y=None, height=dp(60), halign="center")
        self.status.bind(size=lambda *_: setattr(self.status, "text_size", self.status.size))
        root.add_widget(self.status)
        self.validate_btn = Button(text="Validate & Load Models", size_hint_y=None, height=dp(50))
        self.validate_btn.bind(on_release=self.validate)
        root.add_widget(self.validate_btn)
        self.model_spinner = Spinner(text="Select model", values=[], size_hint_y=None, height=dp(48))
        root.add_widget(self.model_spinner)
        self.open_btn = Button(text="Open Chat", disabled=True, size_hint_y=None, height=dp(50))
        self.open_btn.bind(on_release=self.open_chat)
        root.add_widget(self.open_btn)
        self.add_widget(root)
        self._models = {}

    def validate(self, *_):
        key = self.key_input.text.strip()
        if not key:
            self.status.text = "Please enter an API key."
            return
        self.validate_btn.disabled = True
        self.status.text = "Validating with Gemini..."
        threading.Thread(target=self._validate_worker, args=(key,), daemon=True).start()

    def _validate_worker(self, key):
        try:
            models = list_generation_models(key)
            Clock.schedule_once(lambda dt: self._on_models(key, models))
        except GeminiError as e:
            Clock.schedule_once(lambda dt: self._fail(redact(str(e), key)))

    def _on_models(self, key, models):
        self._models = {name: mid for mid, name in models}
        self.model_spinner.values = list(self._models.keys())
        self.model_spinner.text = list(self._models.keys())[0]
        self._pending_key = key
        self.validate_btn.disabled = False
        self.open_btn.disabled = False
        self.status.text = f"Key valid. {len(models)} models found."

    def _fail(self, msg):
        self.validate_btn.disabled = False
        self.status.text = msg

    def open_chat(self, *_):
        model = self._models.get(self.model_spinner.text)
        if not model:
            self.status.text = "Choose a model first."
            return
        self.app.settings.update(api_key=self._pending_key, model=model)
        self.app.show_chat()


class ChatScreen(Screen):
    def __init__(self, app, **kw):
        super().__init__(name="chat", **kw)
        self.app = app
        self.history = []   # session only; persistence is a later step
        self.busy = False
        root = BoxLayout(orientation="vertical", padding=dp(8), spacing=dp(6))
        top = BoxLayout(size_hint_y=None, height=dp(48))
        self.title = Label(text="JARVIS", color=CYAN, font_size=dp(20))
        top.add_widget(self.title)
        back = Button(text="Setup", size_hint_x=None, width=dp(90))
        back.bind(on_release=lambda *_: self.app.show_setup())
        top.add_widget(back)
        root.add_widget(top)
        self.scroll = ScrollView()
        self.log = BoxLayout(orientation="vertical", size_hint_y=None, spacing=dp(8))
        self.log.bind(minimum_height=self.log.setter("height"))
        self.scroll.add_widget(self.log)
        root.add_widget(self.scroll)
        self.status = Label(text="", color=TEXT, size_hint_y=None, height=dp(20))
        root.add_widget(self.status)
        row = BoxLayout(size_hint_y=None, height=dp(90), spacing=dp(6))
        self.input = TextInput(hint_text="Message JARVIS...", multiline=True)
        row.add_widget(self.input)
        self.send_btn = Button(text="Send", size_hint_x=None, width=dp(80))
        self.send_btn.bind(on_release=self.send)
        row.add_widget(self.send_btn)
        root.add_widget(row)
        self.add_widget(root)

    def on_pre_enter(self, *_):
        self.title.text = f"JARVIS  |  {self.app.settings.model}"

    def add_message(self, text, is_ai):
        b = Bubble(text, is_ai, on_long_press=self.show_menu if is_ai else None)
        b.bg_color = (0, 0, 0, 0)
        self.log.add_widget(b)
        Clock.schedule_once(lambda dt: setattr(self.scroll, "scroll_y", 0))

    def send(self, *_):
        text = self.input.text.strip()
        if not text or self.busy:
            return
        self.busy = True
        self.send_btn.disabled = True
        self.input.text = ""
        self.add_message(text, is_ai=False)
        self.history.append({"role": "user", "text": text})
        self.status.text = "JARVIS is thinking..."
        s = self.app.settings
        threading.Thread(target=self._worker, args=(s.api_key, s.model,
                         list(self.history), s.instruction), daemon=True).start()

    def _worker(self, key, model, history, instruction):
        try:
            reply = generate_reply(key, model, history, instruction)
            Clock.schedule_once(lambda dt: self._on_reply(reply))
        except GeminiError as e:
            Clock.schedule_once(lambda dt: self._on_error(redact(str(e), key)))

    def _on_reply(self, reply):
        self.history.append({"role": "model", "text": reply})
        self.add_message(reply, is_ai=True)
        self._done("")

    def _on_error(self, msg):
        self.history.pop()  # drop the unanswered user turn so retry is clean
        self.add_message(f"[Error] {msg}", is_ai=True)
        self._done("Tap Send to retry.")

    def _done(self, status):
        self.busy = False
        self.send_btn.disabled = False
        self.status.text = status

    def show_menu(self, bubble):
        box = BoxLayout(orientation="vertical", spacing=dp(8), padding=dp(10))
        pop = Popup(title="AI response", content=box, size_hint=(0.85, None), height=dp(260))
        copy_btn = Button(text="Copy")
        copy_btn.bind(on_release=lambda *_: (Clipboard.copy(bubble.full_text),
                                             setattr(self.status, "text", "Copied."), pop.dismiss()))
        select_btn = Button(text="Select Text")
        select_btn.bind(on_release=lambda *_: (pop.dismiss(), self.show_selectable(bubble.full_text)))
        close_btn = Button(text="Close")
        close_btn.bind(on_release=pop.dismiss)
        for b in (copy_btn, select_btn, close_btn):
            box.add_widget(b)
        pop.open()

    def show_selectable(self, text):
        box = BoxLayout(orientation="vertical", padding=dp(10), spacing=dp(8))
        # readonly multiline TextInput gives real long-press / drag text selection
        ti = TextInput(text=text, readonly=True, multiline=True, use_handles=True)
        box.add_widget(ti)
        close = Button(text="Close", size_hint_y=None, height=dp(48))
        box.add_widget(close)
        pop = Popup(title="Select text, then long-press to copy", content=box, size_hint=(0.95, 0.9))
        close.bind(on_release=pop.dismiss)
        pop.open()


class JarvisApp(App):
    def build(self):
        self.settings = SettingsManager(Storage(self.user_data_dir))
        self.sm = ScreenManager()
        self.sm.add_widget(SetupScreen(self))
        self.sm.add_widget(ChatScreen(self))
        from kivy.core.window import Window
        Window.clearcolor = BG
        if self.settings.api_key and self.settings.model:
            self.show_chat()
        return self.sm

    def show_chat(self):
        self.sm.current = "chat"

    def show_setup(self):
        self.sm.current = "setup"


if __name__ == "__main__":
    JarvisApp().run()
